interface InterfaceClass
{
    public int sum_all_variables();
}
