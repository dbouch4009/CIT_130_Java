/*import java.io.IOException;
import java.net.ServerSocket;

class FunctionServer extends Thread {
    private ServerSocket serverSocket;
    public FunctionServer() throws IOException {
        this.serverSocket = new ServerSocket(50000);
    }

    public void run() {
        System.out.println("    FunctionServer");
        try{
            // recieve msg from client and print msg -> "Server: " + msg
            // send reply ->  msg + " Server Response Confirmation"
            break;
        }
    } catch (java.io.IOException e) {
        e.printStackTrace();
    }
}
    public String word_letter_count(String msg)
    {
        //implement function to count words and letters
        return "-1";
    }
}
*/