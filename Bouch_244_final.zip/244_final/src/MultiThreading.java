public class MultiThreading
{
    public void start_threads(ThreadObject[] t){
        // intitae all threads
        // wait until all threads have ended isAlive()?
    }
}
