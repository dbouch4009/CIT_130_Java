public class Truck extends Vehicle
{
    private String bedSize;
    private String engineSize;
}
