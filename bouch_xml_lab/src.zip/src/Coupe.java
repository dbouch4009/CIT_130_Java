public class Coupe extends Vehicle
{
    private boolean isTurbo;
    private String engineSize;
}
