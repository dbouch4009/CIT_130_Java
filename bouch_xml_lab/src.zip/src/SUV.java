public class SUV extends Vehicle
{
    private String seatCount;
    private String rowsCount;


}
