public class Minivan extends Vehicle
{
    private String seatsCount;
}
