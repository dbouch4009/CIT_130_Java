import javax.swing.JFrame;

public class Bouch_Middle_Man_Main
{
    public static void main(String[] args)
    {
        Bouch_Middle_Man serverOne = new Bouch_Middle_Man();
        serverOne.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        serverOne.StartUp();
    }
}
