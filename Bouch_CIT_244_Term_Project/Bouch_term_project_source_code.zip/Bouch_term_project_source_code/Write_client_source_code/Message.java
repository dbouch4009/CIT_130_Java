public class Message
{
    public String toXML(String input)
    {
        return "<body>" + input + "</body>";
    }

    public void fromXML(String input)
    {

    }
}
