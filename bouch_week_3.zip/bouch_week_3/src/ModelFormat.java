public interface ModelFormat
{
    String pidFormat(String idIn);
}
