public class ModelNotFoundException extends Exception
{
    // Vehicle model does not exist
    public ModelNotFoundException()
    {
        super("Model like this does not exist");
    }

    public ModelNotFoundException(String msg)
    {
        super(msg);
    }
}
