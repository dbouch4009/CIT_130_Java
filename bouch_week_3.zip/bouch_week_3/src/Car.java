import org.omg.CORBA.Environment;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class Car{
    private String make;
    private String model;
    private String[] options = new String[8];
    private String[] parts = new String[9];
    private double price;
    //private Filereader config;

    Scanner inputStream = null;
    String basePath = new File("").getAbsolutePath();
    String path = new File("config.txt").getAbsolutePath();

    public Car()
    {
        try
        {
            inputStream = new Scanner(new FileInputStream(path));
            //inputStream = new Scanner(new FileInputStream("C:/Users/Damian/Documents/CCAC/spring_2018/CIT_244/week_1/AnyCarManufacturer/src/config.txt"));
        }
        catch (FileNotFoundException exc)
        {
            System.out.println("Problem opening file");
            System.exit(0);
        }
    }

    public void setMake(String makeIn)
    {
        make = makeIn;
    }

    public String getMake()
    {
        return make;
    }

    public void setModel(String modelIn)
    {
        model = modelIn;
    }

    public String getModel()
    {
        return model;
    }

    public void setOptions(String[] optionsIn)
    {
        for(int i = 0; i < optionsIn.length; i++)
        {
            options[i] = optionsIn[i];
        }
    }

    public String[] getOptions()
    {
        return options;
    }

    public void setParts(String[] partsIn)
    {
        for(int i = 0; i < partsIn.length; i++)
        {
            parts[i] = partsIn[i];
        }
    }

    public String[] getParts()
    {
        return parts;
    }

    public void setPrice(double priceIn)
    {
        price = priceIn;
    }

    public double getPrice()
    {
        return price;
    }

    public String toString()
    {
        System.out.println("ToString Writer: ");
        StringBuilder buildString = new StringBuilder("");
        String partsWriter[] = this.getParts();
        String optionsWriter[] = this.getOptions();

        buildString.append(System.getProperty("line.separator"));
        buildString.append("Make: " + this.getMake());
        buildString.append(System.getProperty("line.separator"));
        buildString.append("Model: " + this.getModel());
        buildString.append(System.getProperty("line.separator"));
        buildString.append("Options: " );

        for(int i = 0; i < options.length; i++)
        {
            buildString.append(System.getProperty("line.separator"));
            buildString.append(optionsWriter[i].toString());
        }

        buildString.append(System.getProperty("line.separator"));

        buildString.append("Parts: " );
        for(int i = 0; i < parts.length; i++)
        {
            buildString.append(System.getProperty("line.separator"));
            buildString.append(partsWriter[i].toString());
        }
        buildString.append(System.getProperty("line.separator"));

        buildString.append("Price: " + getPrice());

        buildString.append(System.getProperty("line.separator"));

        String returnString = buildString.toString();
        return returnString;
    }
}