public class SedanOptionsException extends Exception
{
    //Exception if option specific to Sedan does not exist
    public SedanOptionsException()
    {
        super("Sedan options given not within option index");
    }

    public SedanOptionsException(String msg)
    {
        super(msg);
    }

}
