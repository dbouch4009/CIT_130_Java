public class SUVOptionsException extends Exception
{
    //Exception if SUV options does not exist
    public SUVOptionsException()
    {
        super("SUV options given not within option index");
    }

    public SUVOptionsException(String msg)
    {
        super(msg);
    }

}
