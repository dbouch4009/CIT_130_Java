public class MinivanOptionsException extends Exception
{
    //Exception if Minivan option given does not exist
    public MinivanOptionsException()
    {
        super("Minivan options given not within option index");
    }

    public MinivanOptionsException(String msg)
    {
        super(msg);
    }

}
