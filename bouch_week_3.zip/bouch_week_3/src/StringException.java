public class StringException extends Exception
{
    //If user input contains anything other than numbers
    public StringException()
    {
        super("Invalid characters within pid");
    }

    public StringException(String msg)
    {
        super(msg);
    }

}
