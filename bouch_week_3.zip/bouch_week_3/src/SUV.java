public class SUV extends Vehicle implements VehicleSpecs
{
    private String seatsCount;
    private String rowsCount;
    private String modelName;
    private String specsIndicator;

    public SUV(String idIn, String modelIn)
    {
        super(idIn);
        modelName = modelIn;
        setSpecsIndicator(modelName);
        setRows();
        setSeatsCount();
    }

    public void setSpecsIndicator(String modelIn)
    {
        this.specsIndicator = modelIn.substring(modelIn.length() - 1);
        System.out.println("SPECS TEST: " + specsIndicator);
    }

    public String getRows()
    {
        return rowsCount;
    }

    public void setRows()
    {
        setSpecsIndicator(this.getModel());
        if(specsIndicator.equals("B") || specsIndicator.equals("X"))
        {
            rowsCount = "2";
        }
        else {
            rowsCount = "3";
        }
    }

    public String getSeatsCount()
    {
        return seatsCount;
    }

    public void setSeatsCount()
    {
        setSpecsIndicator(this.getModel());

        if(specsIndicator.equals("B") || specsIndicator.equals("SS"))
        {
            seatsCount = "5";
        }
        else if(specsIndicator.equals("XL"))
            seatsCount = "7";
        else{
            seatsCount = "8";
        }
    }

    public String getModel()
    {
        return this.modelName;
    }

}
