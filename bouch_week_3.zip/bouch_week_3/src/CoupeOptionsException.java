public class CoupeOptionsException extends Exception
{
    //Exception if options specific to Coupe does not exist
    public CoupeOptionsException()
    {
        super("Coupe options given not within option index");
    }

    public CoupeOptionsException(String msg)
    {
        super(msg);
    }
}
