public class Sedan extends Vehicle implements VehicleSpecs
{
    private boolean isHatchback;
    private String engineSize;
    private String sedanType;
    private String modelName;
    private String specsIndicator;

    public Sedan(String idIn, String modelIn)
    {
        super(idIn);
        modelName = modelIn;
        setSpecsIndicator(modelName);
        setEngine();
        setIsHatchback();
    }

    public void setSpecsIndicator(String modelIn)
    {
        this.specsIndicator = modelIn.substring(modelIn.length() - 1);
    }

    public void setIsHatchback()
    {
        if(specsIndicator.equals("XL") || specsIndicator.equals("P"))
        {
            isHatchback = true;
        }
        else {
            isHatchback = false;
        }
    }

    public boolean getIsHatchBack()
    {
        return isHatchback;
    }

    public void setEngine()
    {
        if(specsIndicator.equals("L") || specsIndicator.equals("P"))
        {
            engineSize = "6";
        }
        else
            engineSize = "4";
    }

    public String getEngineSize()
    {
        return engineSize;
    }
}
