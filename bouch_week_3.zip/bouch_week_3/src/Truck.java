public class Truck extends Vehicle implements VehicleSpecs
{
    private String bedSize;
    private String engineSize;
    private String modelName;
    private String specsIndicator;

    public Truck(String idIn, String modelIn)
    {
        super(idIn);
        modelName = modelIn;
        setSpecsIndicator(modelName);
        setBedSize();
        setEngineSize();
    }

    public void setSpecsIndicator(String modelIn)
    {
        this.specsIndicator = modelIn.substring(modelIn.length() - 1);
    }

    public String getBedSize()
    {
        return bedSize;
    }

    public void setBedSize()
    {
        setSpecsIndicator(this.getModel());
        if(specsIndicator.equals("B") || specsIndicator.equals("K"))
        {
            bedSize = "4";
        }
        else if(specsIndicator.equals("XL"))
        {
            bedSize = "8";
        }
        else {
            bedSize = "6";
        }
    }

    public String getEngineSize()
    {
        return engineSize;
    }

    public void setEngineSize()
    {
        setSpecsIndicator(this.getModel());
        if(specsIndicator.equals("K") || specsIndicator.equals("T"))
        {
            engineSize = "8";
        }
        else {
            engineSize = "6";
        }
    }

    public String getModel()
    {
        return this.modelName;
    }

}
