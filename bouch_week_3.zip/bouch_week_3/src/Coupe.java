public class Coupe extends Vehicle implements VehicleSpecs
{
    private boolean isTurbo;
    private String engineSize;
    private String modelName;
    private String specsIndicator;

    public Coupe(String idIn, String modelIn)
    {
        super(idIn);
        modelName = modelIn;
        setSpecsIndicator(modelName);
        setEngineSize();
        setTurbo();
    }

    public void setSpecsIndicator(String modelIn)
    {
        this.specsIndicator = modelIn.substring(modelIn.length() - 1);
    }

    public boolean getTurbo()
    {
        return isTurbo;
    }

    public void setTurbo()
    {
        if(specsIndicator.equals("B") || specsIndicator.equals("S"))
        {
            isTurbo = false;
        }
        else {
            isTurbo = true;
        }
    }

    public String getEngineSize()
    {
        return engineSize;
    }

    public void setEngineSize()
    {
        if(specsIndicator.equals("B") || specsIndicator.equals("SS"))
        {
            engineSize = "2.0";
        }
        else if(specsIndicator.equals("S") || specsIndicator.equals("SSL"))
            engineSize = "3.2";
        else{
            engineSize = "5.0";
        }

    }

}


