/*
 * Name: Damian Bouch
 * Class: CIT 244
 * Date: Mar 11, 2018
 * Description: Adding Exception Handling to existing AnyCar manufacturing program

 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;

class AnyCarManufacturer {
    //   public static String[] anyCarConfig = new String[]; // Global String Array Manufactoring Configuration

    //Main()
    public static void main(String[] args)
    {
        System.out.println("Beginning AnyCar Program with OOP, by Damian Bouch");

        request();
    }

    //Request CLI
    public static void request()
    {
        Scanner keyboardIn = new Scanner(System.in);
        String inputID = "";

        System.out.println("");  //blank line for cosmetic purposes
        System.out.println("Please enter a PID: ");
        inputID = keyboardIn.nextLine();
        char firstChar = inputID.charAt(0);
        System.out.println("Input ID: " + inputID);
        try {
            int i = 0;
            while(i < inputID.length())
            {
                if(Character.isLetter(inputID.charAt(i)))
                {
                    throw new StringException("StringException: Invalid character: " + inputID.charAt(i));
                }
                i++;
            }

            int inputLength = inputID.length();

            if(!(inputLength == 12 || inputLength == 15 || inputLength == 14))
            {
                switch (firstChar)
                {
                    case'1':
                        throw new MakeFormatException("MakeFormatException: ThisAuto must have a 12 character PID");
                    case'2':
                        throw new MakeFormatException("MakeFormatException: ThatAuto must have a 14 character PID");
                    case'3':
                        throw new MakeFormatException("MakeFormatException: OtherAuto must have a 15 character PID");
                    default:
                        throw new MakeFormatException("MakeFormatException: Wrong number of characters: " + inputLength);
                }
            }

            if (inputID.equals("-1")) {
                System.out.println("Finished");
                System.exit(0);
            } else {
                buildVehicle(inputID);
                request();
            }
        }
        catch (StringException exc)
        {
            System.out.println("StringException occurred");
            System.out.println(exc.getMessage());
            System.exit(0);
        }
        catch (MakeFormatException exc)
        {
            System.out.println(exc.getMessage());
            System.exit(0);
        }
        catch (Exception exc)
        {
            System.out.println("Something else went wrong");
            System.exit(0);
        }
    }

    //builds object in memory and prints
    public static void buildVehicle(String idIn)
    {
        {
            Vehicle myVehicle = new Vehicle(idIn);
            myVehicle.setMake(idIn);
            myVehicle.setVehicleType(idIn);
            myVehicle.setModel(idIn);
            myVehicle.setExtColor(idIn);
            myVehicle.setIntColor(idIn);
            myVehicle.setPowerTrain(idIn);
            myVehicle.setSeat(idIn);
            myVehicle.setRadio(idIn);
            myVehicle.setTire(idIn);
            myVehicle.setRim(idIn);
            myVehicle.setMiscSelections(idIn);
            myVehicle.setVehicleType(idIn);

            //String myOptions[] = fetchOptions(idIn);
            //String myParts[] = fetchParts(idIn, myOptions);
            //double myPrice = fetchPrice(myParts);
            //myVehicle.setOptions(myOptions);
            //myVehicle.setParts(myParts);
            //myVehicle.setPrice(myPrice);

            //Output to console
            String output = myVehicle.toString();
            System.out.println(output);
        }
    }
}
