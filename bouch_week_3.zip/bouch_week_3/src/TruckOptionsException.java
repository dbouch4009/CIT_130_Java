public class TruckOptionsException extends Exception
{
    //Exception if Truck option does not exist
    public TruckOptionsException()
    {
        super("Truck options given not within option index");
    }

    public TruckOptionsException(String msg)
    {
        super(msg);
    }

}
