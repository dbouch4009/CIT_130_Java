public class Minivan extends Vehicle implements VehicleSpecs
{
    private String seatsCount;
    private String modelName;
    private String specsIndicator;

    public Minivan(String idIn, String modelIn)
    {
        super(idIn);
        modelName = modelIn;
        setSpecsIndicator(modelName);
        setSeatsCount();
    }

    public void setSpecsIndicator(String modelIn)
    {
        this.specsIndicator = modelIn.substring(modelIn.length() - 1);
        System.out.println("SPECS TEST: " + specsIndicator);
    }

    public String getSeatsCount()
    {
        return seatsCount;
    }

    public void setSeatsCount()
    {
        try {
            setSpecsIndicator(this.getModel());
            if (specsIndicator.equals("B") || specsIndicator.equals("L")) {
                seatsCount = "7";
            } else if (specsIndicator.equals("P") || specsIndicator.equals("H")) {
                seatsCount = "8";
            } else {
                throw new MinivanOptionsException("Minivan option " + specsIndicator + " is not present for Minivan.");
            }
        }
        catch(MinivanOptionsException exc)
        {
            System.out.println(exc.getMessage());
            System.exit(0);
        }
    }

    public String getModel()
    {
        return this.modelName;
    }

}
