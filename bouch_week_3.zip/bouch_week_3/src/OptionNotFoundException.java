public class OptionNotFoundException extends Exception
{
    //Option id does not exist within option index, e.g., 3 given for Powertrain when only digits 1 or 2 can be taken
    public OptionNotFoundException()
    {
        super("Options given not within option index");
    }

    public OptionNotFoundException(String msg)
    {
        super(msg);
    }
}
