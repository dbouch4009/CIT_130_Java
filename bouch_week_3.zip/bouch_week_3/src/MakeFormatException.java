public class MakeFormatException extends Exception
{
    //If the input pid length does not match the Car company's length, i.e., 12 or 16 digits
    public MakeFormatException()
    {
        super("Invalid pid format");
    }

    public MakeFormatException(String msg)
    {
        super(msg);
    }
}
