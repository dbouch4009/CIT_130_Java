import org.omg.CORBA.Environment;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Vehicle implements ModelFormat{
    private String make;
    private String model;
    private String[] options = new String[8];
    private String[] parts = new String[9];
    private double totalPrice;
    private String vehicleType;
    private String instanceId;
    public ArrayList<String> configInMemory = new ArrayList<String>();
    public ArrayList<String> priceListOfItems = new ArrayList<String>();

    private String modelArray;
    private String extColor;
    private String intColor;
    private String powerTrain;
    private String seatType;
    private String radioType;
    private String tireSize;
    private String rimSize;
    private String miscSelections;

    Scanner inputStream = null;

    public Vehicle(String idIn)
    {
        try
        {
            this.setMake(idIn);
            String path = new File(this.getMake() + ".txt").getAbsolutePath();
            inputStream = new Scanner(new FileInputStream(path));
            //System.out.println("File name: " + path);
            //inputStream = new Scanner(new FileInputStream("C:/Users/Damian/Documents/CCAC/spring_2018/CIT_244/week_1/AnyCarManufacturer/src/config.txt"));
        }
        catch (FileNotFoundException exc)
        {
            String path = new File(this.getMake() + ".txt").getAbsolutePath();
            System.out.println("Problem opening file: " + path.toString());
            System.exit(0);
        }
        instanceId = idIn;
        int configCounter = 0;
        while(inputStream.hasNextLine())
        {
            String newLine = inputStream.nextLine();
            configInMemory.add(newLine);
            configCounter++;
        }

        setVehicleType(idIn);

        inputStream.close();
        //config = configIn;
    }

    public String pidFormat(String idIn)
    {
        int inputLength = 0;
        inputLength = idIn.length();
        String formattedId = "";

        String pidMake = this.getMake();

        //Acquires user's selections based on make
        switch(pidMake)
        {
            case "ThatAuto":
                modelArray = idIn.substring(0,6);
                extColor = idIn.substring(7,1);
                intColor = idIn.substring(8,1);
                powerTrain = idIn.substring(9,1);
                seatType = idIn.substring(10,1);
                radioType = idIn.substring(11,1);
                tireSize = idIn.substring(12,1);
                rimSize = idIn.substring(13,1);
                miscSelections = idIn.substring(14,2);
                break;
            case"ThisAuto":
                modelArray = idIn.substring(0,4);
                extColor = idIn.substring(5,1);
                intColor = idIn.substring(6,1);
                powerTrain = idIn.substring(7,1);
                seatType = idIn.substring(8,1);
                radioType = idIn.substring(9,1);
                tireSize = idIn.substring(10,1);
                rimSize = idIn.substring(11,1);
                miscSelections = idIn.substring(12,2);
                break;
            case"OtherAuto":
                modelArray = idIn.substring(0,4);
                extColor = idIn.substring(5,1);
                intColor = idIn.substring(6,1);
                powerTrain = idIn.substring(7,1);
                seatType = idIn.substring(8,1);
                radioType = idIn.substring(9,1);
                tireSize = idIn.substring(10,1);
                rimSize = idIn.substring(11,1);
                miscSelections = idIn.substring(12,4);
                break;
            default:
                System.out.println("Invalid pidMake");
                break;
        }
        System.out.println("Formatted ID: " + formattedId);
        return formattedId;
    }

    public void setMake(String idIn)
    {
        try {
            String makeIndex = idIn.substring(0, 1);
            String makeString = "";
            switch (makeIndex) {
                case "1":
                    makeString = "ThisAuto";
                    break;
                case "2":
                    makeString = "ThatAuto";
                    break;
                case "3":
                    makeString = "OtherAuto";
                    break;
                default:
                    makeString = "Invalid Make";
                    break;
            }
            if(makeString.equals("Invalid Make"))
            {
                throw new MakeNotFoundException("MakeNotFound: The make provided with this index is not valid: " + makeIndex.toString());
            }
            this.make = makeString;
        }
        catch (MakeNotFoundException exc)
        {
            System.out.println(exc.getMessage());
            System.exit(0);
        }
    }

    public String getMake()
    {
        return make;
    }

    public void setVehicleType(String idIn)
    {
        try {
            String typeIndex = idIn.substring(1, 2);
            String typeString = "";
            switch (typeIndex) {
                case "1":
                    typeString = "Sedan";
                    break;
                case "2":
                    typeString = "Coupe";
                    break;
                case "3":
                    typeString = "Minivan";
                    break;
                case "4":
                    typeString = "SUV";
                    break;
                case "5":
                    typeString = "Truck";
                    break;
                default:
                    typeString = "Invalid Type";
                    break;
            }
            if(typeString.equals("Invalid Type"))
            {
                throw new ModelNotFoundException("ModelNotFound: No appropriate vehicle type is in " + idIn + " for company " + this.getMake());
            }

            char modelExceptionFinder;
            if(this.getMake().equals("ThisAuto") || this.getMake().equals("OtherAuto"))
            {
                modelExceptionFinder = idIn.charAt(3);
                int modelExceptionFinderInt = Character.getNumericValue(modelExceptionFinder);
                if(modelExceptionFinderInt > 5)
                {
                    switch(typeIndex){
                        case "1":
                            throw new SedanOptionsException("This options package: " + typeString + " is not supported for Sedans. Only 1 - 5 for B,S,L,LX, and P are available");

                        case "2":
                            throw new CoupeOptionsException("This options package: " + typeString + " is not supported for Coupes. Only 1 - 5 for B,S,SS,SSL,and SSP are available");

                        case "3":
                            throw new MinivanOptionsException("This options package: " + typeString + " is not supported for Minivans. Only 1 - 5 for B,L,XL,P, and H are available");

                        case "4":
                            throw new SUVOptionsException("This options package: " + typeString + " is not supported for SUV. Only 1 - 5 for B,X,XL,SL,SXL are available");

                        case "5":
                            throw new TruckOptionsException("This options package: " + typeString + " is not supported for Trucks. Only 1 - 5 for B,X,XL,K, and T are available");

                        default:
                            typeString = "Invalid Type";
                            break;
                    }
                    throw new ModelNotFoundException("ModelNotFound: No appropriate vehicle type for model code " + modelExceptionFinder);
                }
            } else if(this.getMake().equals("ThatAuto"))
            {
                modelExceptionFinder = idIn.charAt(3);
                String modelExceptionFinderTail = idIn.substring(4,6);
                int modelExceptionFinderInt = Character.getNumericValue(modelExceptionFinder);
                if(modelExceptionFinderInt > 5 || !modelExceptionFinderTail.equals("11"))
                {
                    if(modelExceptionFinderInt > 5)
                    {
                        switch(typeIndex){
                            case "1":
                                throw new SedanOptionsException("This options package: " + typeString + " is not supported for Sedans. Only 1 - 5 for B,S,L,LX, and P are available");

                            case "2":
                                throw new CoupeOptionsException("This options package: " + typeString + " is not supported for Coupes. Only 1 - 5 for B,S,SS,SSL,and SSP are available");

                            case "3":
                                throw new MinivanOptionsException("This options package: " + typeString + " is not supported for Minivans. Only 1 - 5 for B,L,XL,P, and H are available");

                            case "4":
                                throw new SUVOptionsException("This options package: " + typeString + " is not supported for SUV. Only 1 - 5 for B,X,XL,SL,SXL are available");

                            case "5":
                                throw new TruckOptionsException("This options package: " + typeString + " is not supported for Trucks. Only 1 - 5 for B,X,XL,K, and T are available");

                            default:
                                typeString = "Invalid Type";
                                break;
                        }
                        throw new ModelNotFoundException("ModelNotFound: No appropriate vehicle type for model code " + modelExceptionFinder);
                    }
                    throw new ModelNotFoundException("ModelNotFound: No appropriate vehicle type for model code " + modelExceptionFinder + modelExceptionFinderTail);
                }
            }
            vehicleType = typeString;
        }
        catch(SedanOptionsException exc)
        {
            System.out.println(exc.getMessage());
        }
        catch(CoupeOptionsException exc)
        {
            System.out.println(exc.getMessage());
        }
        catch(MinivanOptionsException exc)
        {
            System.out.println(exc.getMessage());
        }
        catch(SUVOptionsException exc)
        {
            System.out.println(exc.getMessage());
        }
        catch(TruckOptionsException exc)
        {
            System.out.println(exc.getMessage());
        }
        catch(ModelNotFoundException exc)
        {
            System.out.println(exc.getMessage());
        }
        catch(Exception exc)
        {
            System.out.println(exc.getMessage());
        }
        finally
        {
            System.out.println("Fininished with Vehicle Type");
        }
    }

    public String getVehicleType()
    {
        return this.vehicleType;
    }
    public void setModel(String idIn)
    {
        //Sets directly to options[0]
        String myModel = "";
        String modelCode = this.getMake();
        String extColorSubstring = "";
        int startingIndex = 0;
        int lengthIndex = 0;

        switch(modelCode)
        {
            case "ThisAuto":
                startingIndex = 0;
                lengthIndex = 25;
                extColorSubstring = idIn.substring(0,4);
                for(int i = startingIndex; i < lengthIndex; i++)
                {
                    String testString = configInMemory.get(i);
                    String[] subStrings = testString.split(" ");
                    if(subStrings[0].contains(extColorSubstring))
                    {
                        myModel = subStrings[1];
                        String myPrice = "";
                        myPrice = subStrings[2];
                        priceListOfItems.add(myPrice);
                    }
                }
                break;
            case "ThatAuto":
                startingIndex = 0;
                lengthIndex = 25;
                extColorSubstring = idIn.substring(0,6);
                for(int i = startingIndex; i <= lengthIndex; i++)
                {
                    String testString = configInMemory.get(i);
                    String[] subStrings = testString.split(" ");
                    if(subStrings[0].contains(extColorSubstring))
                    {
                        myModel = subStrings[1];
                        String myPrice = "";
                        myPrice = subStrings[2];
                        priceListOfItems.add(myPrice);
                    }
                }
                break;
            case "OtherAuto":
                startingIndex = 0;
                lengthIndex = 25;
                extColorSubstring = idIn.substring(0,4);
                for(int i = startingIndex; i <= lengthIndex; i++)
                {
                    String testString = configInMemory.get(i);
                    String[] subStrings = testString.split(" ");
                    if(subStrings[0].contains(extColorSubstring))
                    {
                        myModel = subStrings[1];
                        String myPrice = "";
                        myPrice = subStrings[2];
                        priceListOfItems.add(myPrice);
                    }
                }
                break;
            default:
                myModel = "Invalid setModel";
                break;
        }
        //options[0] = myModel;
        this.model = myModel;
        System.out.println("Model: " + this.model);
    }

    public String getModel()
    {
        return this.model;
    }


    public String[] getOptions()
    {
        return options;
    }

    public void setParts(String[] partsIn)
    {
        for(int i = 0; i < partsIn.length; i++)
        {
            parts[i] = partsIn[i];
        }
    }

    public String[] getParts()
    {
        return parts;
    }

    public void setPrice(String idIn)
    {
        double myPrice = 0;
        totalPrice = myPrice;
    }

    public double getPrice()
    {
        return totalPrice;
    }

    public String toString()
    {
        System.out.println("*********  ToString Writer: ");
        StringBuilder buildString = new StringBuilder("");
        String partsWriter[] = this.getParts();
        String optionsWriter[] = this.getOptions();

        buildString.append(System.getProperty("line.separator"));
        buildString.append("Make: " + this.getMake());
        buildString.append(System.getProperty("line.separator"));
        buildString.append("Model: " + this.getModel() + " " + priceListOfItems.get(0));
        buildString.append(System.getProperty("line.separator"));
        buildString.append("Options: " );

        for(int i = 0; i < options.length; i++)
        {
            buildString.append(System.getProperty("line.separator"));
            buildString.append(optionsWriter[i].toString());
            buildString.append(" Price: " + priceListOfItems.get(i + 1));
        }

        buildString.append(System.getProperty("line.separator"));

        buildString.append("Total Price: " + collectPrices());

        buildString.append(System.getProperty("line.separator"));

        this.setVehicleType(instanceId);

        switch(vehicleType.toLowerCase())
        {
            case"sedan":
                System.out.println("Sedan detected");
                Sedan mySedan = new Sedan(instanceId, this.model);
                buildString.append("Engine: " + mySedan.getEngineSize());
                buildString.append(System.getProperty("line.separator"));
                buildString.append("Hatch? " + mySedan.getIsHatchBack());
                buildString.append(System.getProperty("line.separator"));
                break;
            case"coupe":
                System.out.println("Coupe detected");
                Coupe myCoupe = new Coupe(instanceId, this.model);
                buildString.append("Engine: " + myCoupe.getEngineSize());
                buildString.append(System.getProperty("line.separator"));
                buildString.append("Turbo? " + myCoupe.getTurbo());
                buildString.append(System.getProperty("line.separator"));
                break;
            case"minivan":
                System.out.println("Minivan detected");
                Minivan myMini = new Minivan(instanceId, this.model);
                buildString.append("Seats: " + myMini.getSeatsCount());
                buildString.append(System.getProperty("line.separator"));
                break;
            case"suv":
                System.out.println("SUV detected");
                SUV mySUV = new SUV(instanceId, this.model);
                buildString.append("Seats: " + mySUV.getSeatsCount());
                buildString.append(System.getProperty("line.separator"));
                buildString.append("Rows: " + mySUV.getRows());
                buildString.append(System.getProperty("line.separator"));
                break;
            case"truck":
                System.out.println("Truck detected");
                Truck myTruck = new Truck(instanceId, this.model);
                buildString.append("Bed Size: " + myTruck.getBedSize());
                buildString.append(System.getProperty("line.separator"));
                buildString.append("Engine Size: " + myTruck.getEngineSize());
                buildString.append(System.getProperty("line.separator"));
                break;
            default:
                System.out.println("Unable to read vehicle type");
        }
        String returnString = buildString.toString();
        System.out.println("Finished build string");
        return returnString;
    }

    public void setExtColor(String idIn)
    {
        //Sets directly to options[0]
        String myExtColor = "";
        String modelCode = this.getMake();
        String extColorSubstring = "";
        int startingIndex = 0;
        int lengthIndex = 0;
        ArrayList<String> exceptionPrintList = new ArrayList<>();

        try {
            switch (modelCode) {
                case "ThisAuto":
                    startingIndex = 28;
                    lengthIndex = 38;
                    extColorSubstring = idIn.substring(4, 5);
                    if(Integer.parseInt(extColorSubstring) > 9)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Exterior Color");
                    }
                    for (int i = startingIndex; i < lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        exceptionPrintList.add(testString);
                        if (subStrings[0].contains(extColorSubstring)) {
                            myExtColor = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "ThatAuto":
                    extColorSubstring = idIn.substring(6, 7);
                    startingIndex = 28;
                    lengthIndex = 37;
                    if (Integer.parseInt(extColorSubstring) > 9) {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Exterior Color");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myExtColor = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "OtherAuto":
                    extColorSubstring = idIn.substring(4, 5);
                    startingIndex = 28;
                    lengthIndex = 37;
                    if (Integer.parseInt(extColorSubstring) > 9) {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Exterior Color");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myExtColor = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                default:
                    myExtColor = "Invalid setModel";
                    break;
            }
        }
        catch (OptionNotFoundException exc)
        {
            System.out.println(exc.getMessage());
            /*
            TODO: Print each list item
            System.out.println("Available options are: ");
            for (:
                 ) {
                
            }
            */
            System.exit(0);
        }
        options[0] = myExtColor;
        System.out.println("Ext color: " + options[0]);
    }

    public void setIntColor(String idIn)
    {
        //Sets directly to options[0]
        String myIntColor = "";
        String modelCode = this.getMake();
        String extColorSubstring = "";
        int startingIndex = 0;
        int lengthIndex = 0;
        try {
            switch (modelCode) {
                case "ThisAuto":
                    startingIndex = 38;
                    lengthIndex = 48;
                    extColorSubstring = idIn.substring(5, 6);
                    if (Integer.parseInt(extColorSubstring) > 9) {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Interior Color");
                    }
                    for (int i = startingIndex; i < lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myIntColor = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "ThatAuto":
                    startingIndex = 38;
                    lengthIndex = 47;
                    extColorSubstring = idIn.substring(7, 8);
                    if (Integer.parseInt(extColorSubstring) > 9) {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Interior Color");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myIntColor = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "OtherAuto":
                    startingIndex = 38;
                    lengthIndex = 47;
                    extColorSubstring = idIn.substring(5, 6);
                    if (Integer.parseInt(extColorSubstring) > 9) {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Interior Color");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myIntColor = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                default:
                    myIntColor = "Invalid setModel";
                    break;
            }
        }
        catch (OptionNotFoundException exc)
        {
            System.out.println(exc.getMessage());
            System.exit(0);
        }
        options[1] = myIntColor;
        System.out.println("Int color: " + options[1]);
    }

    public void setPowerTrain(String idIn)
    {
        //Sets directly to options[0]
        String myPowertrain = "";
        String modelCode = this.getMake();
        String extColorSubstring = "";
        int startingIndex = 0;
        int lengthIndex = 0;

        try {
            switch (modelCode) {
                case "ThisAuto":
                    startingIndex = 48;
                    lengthIndex = 51;
                    extColorSubstring = idIn.substring(6, 7);
                    if (Integer.parseInt(extColorSubstring) > 2)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for PowerTrain");
                    }
                    for (int i = startingIndex; i < lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myPowertrain = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "ThatAuto":
                    startingIndex = 48;
                    lengthIndex = 50;
                    extColorSubstring = idIn.substring(8, 9);
                    if (Integer.parseInt(extColorSubstring) > 2)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for PowerTrain");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myPowertrain = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "OtherAuto":
                    startingIndex = 48;
                    lengthIndex = 50;
                    extColorSubstring = idIn.substring(6, 7);
                    if (Integer.parseInt(extColorSubstring) > 2)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for PowerTrain");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myPowertrain = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                default:
                    myPowertrain = "Invalid setModel";
                    break;
            }
        }
        catch (OptionNotFoundException exc)
        {
            System.out.println(exc.getMessage());
            System.exit(0);
        }
        options[2] = myPowertrain;
        System.out.println("Powertrain: " + options[2]);
    }

    public void setSeat(String idIn)
    {
        //Sets directly to options[0]
        String mySeat = "";
        String modelCode = this.getMake();
        String extColorSubstring = "";
        int startingIndex = 0;
        int lengthIndex = 0;
        try {
            switch (modelCode) {
                case "ThisAuto":
                    startingIndex = 51;
                    lengthIndex = 55;
                    extColorSubstring = idIn.substring(7, 8);
                    if (Integer.parseInt(extColorSubstring) > 3)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Seats");
                    }
                    for (int i = startingIndex; i < lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            mySeat = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "ThatAuto":
                    startingIndex = 51;
                    lengthIndex = 54;
                    extColorSubstring = idIn.substring(8, 9);
                    if (Integer.parseInt(extColorSubstring) > 3)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Seats");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            mySeat = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "OtherAuto":
                    startingIndex = 51;
                    lengthIndex = 54;
                    extColorSubstring = idIn.substring(6, 7);
                    if (Integer.parseInt(extColorSubstring) > 3)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Seats");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            mySeat = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                default:
                    mySeat = "Invalid setModel";
                    break;
            }
        }
        catch (OptionNotFoundException exc)
        {
            System.out.println(exc.getMessage());
            System.exit(0);
        }
        options[3] = mySeat;
        System.out.println("Seat: " + options[3]);
    }

    public void setRadio(String idIn)
    {
        //Sets directly to options[0]
        String myRadio = "";
        String modelCode = this.getMake();
        String extColorSubstring = "";
        int startingIndex = 0;
        int lengthIndex = 0;
        try {
            switch (modelCode) {
                case "ThisAuto":
                    startingIndex = 55;
                    lengthIndex = 61;
                    extColorSubstring = idIn.substring(7, 8);
                    if (Integer.parseInt(extColorSubstring) > 5)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Radio");
                    }
                    for (int i = startingIndex; i < lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myRadio = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "ThatAuto":
                    startingIndex = 55;
                    lengthIndex = 60;
                    extColorSubstring = idIn.substring(9, 10);
                    if (Integer.parseInt(extColorSubstring) > 5)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Radio");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myRadio = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "OtherAuto":
                    startingIndex = 55;
                    lengthIndex = 60;
                    extColorSubstring = idIn.substring(7, 8);
                    if (Integer.parseInt(extColorSubstring) > 5)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Radio");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myRadio = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                default:
                    myRadio = "Invalid setModel";
                    break;
            }
        }
        catch (OptionNotFoundException exc)
        {
            System.out.println(exc.getMessage());
            System.exit(0);
        }
        options[4] = myRadio;
        System.out.println("Radio: " + options[4]);
    }


    public void setTire(String idIn)
    {
        //Sets directly to options[0]
        String myTire = "";
        String modelCode = this.getMake();
        String extColorSubstring = "";
        int startingIndex = 0;
        int lengthIndex = 0;
        try {
            switch (modelCode) {
                case "ThisAuto":
                    startingIndex = 61;
                    lengthIndex = 65;
                    extColorSubstring = idIn.substring(8, 9);
                    if (Integer.parseInt(extColorSubstring) > 3)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Tire");
                    }
                    for (int i = startingIndex; i < lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myTire = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "ThatAuto":
                    startingIndex = 61;
                    lengthIndex = 64;
                    extColorSubstring = idIn.substring(10, 11);
                    if (Integer.parseInt(extColorSubstring) > 3)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Tire");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myTire = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "OtherAuto":
                    startingIndex = 61;
                    lengthIndex = 64;
                    extColorSubstring = idIn.substring(8, 9);
                    if (Integer.parseInt(extColorSubstring) > 3)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Tire");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myTire = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                default:
                    myTire = "Invalid setModel";
                    break;
            }
        }
        catch (OptionNotFoundException exc)
        {
            System.out.println(exc.getMessage());
            System.exit(0);
        }
        options[5] = myTire;
        System.out.println("Tire: " + options[5]);
    }


    public void setRim(String idIn)
    {
        //Sets directly to options[0]
        String myRim = "";
        String modelCode = this.getMake();
        String extColorSubstring = "";
        int startingIndex = 0;
        int lengthIndex = 0;
        try {
            switch (modelCode) {
                case "ThisAuto":
                    startingIndex = 65;
                    lengthIndex = 71;
                    extColorSubstring = idIn.substring(9, 10);
                    if (Integer.parseInt(extColorSubstring) > 5)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Rims");
                    }
                    for (int i = startingIndex; i < lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myRim = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "ThatAuto":
                    startingIndex = 65;
                    lengthIndex = 70;
                    extColorSubstring = idIn.substring(11, 12);
                    if (Integer.parseInt(extColorSubstring) > 5)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Rims");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myRim = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "OtherAuto":
                    startingIndex = 65;
                    lengthIndex = 70;
                    extColorSubstring = idIn.substring(9, 10);
                    if (Integer.parseInt(extColorSubstring) > 5)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + extColorSubstring + " does not exist for Rims");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(extColorSubstring)) {
                            myRim = subStrings[1];
                            String myPrice = "";
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                default:
                    myRim = "Invalid setModel";
                    break;
            }
        }
        catch (OptionNotFoundException exc)
        {
            System.out.println(exc.getMessage());
            System.exit(0);
        }
        options[6] = myRim;
        System.out.println("Rims: " + options[6]);
    }


    public void setMiscSelections(String idIn)
    {
        //Sets directly to options[0]
        String myMisc = "";
        String modelCode = this.getMake();
        String miscSubstring = "";
        String myPrice = "";
        int startingIndex = 0;
        int lengthIndex = 0;
        try {
            switch (modelCode) {
                case "ThisAuto":
                    startingIndex = 71;
                    lengthIndex = 75;
                    miscSubstring = idIn.substring(10, 11);
                    if (Integer.parseInt(miscSubstring) > 3)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + miscSubstring + " does not exist for Misc");
                    }
                    for (int i = startingIndex; i < lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(miscSubstring)) {
                            myMisc = subStrings[1];
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "ThatAuto":
                    startingIndex = 71;
                    lengthIndex = 87;
                    miscSubstring = idIn.substring(12, 14);
                    if (Integer.parseInt(miscSubstring) > 30)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + miscSubstring + " does not exist for Misc");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(miscSubstring)) {
                            myMisc = subStrings[1];
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                case "OtherAuto":
                    startingIndex = 71;
                    lengthIndex = 327;
                    miscSubstring = idIn.substring(10, 14);
                    if (Integer.parseInt(miscSubstring) > 3333)
                    {
                        throw new OptionNotFoundException("OptionsNotFound: " + miscSubstring + " does not exist for Misc");
                    }
                    for (int i = startingIndex; i <= lengthIndex; i++) {
                        String testString = configInMemory.get(i);
                        String[] subStrings = testString.split(" ");
                        if (subStrings[0].contains(miscSubstring)) {
                            myMisc = subStrings[1];
                            myPrice = subStrings[2];
                            priceListOfItems.add(myPrice);
                        }
                    }
                    break;
                default:
                    myMisc = "Invalid setModel";
                    break;
            }
        }
        catch (OptionNotFoundException exc)
        {
            System.out.println(exc.getMessage());
            System.exit(0);
        }
        options[7] = myMisc;
        System.out.println("Misc: " + options[7]);
    }

    public String collectPrices()
    {
        String priceAsString = "";
        double priceAsDouble = 0;
        double totalPriceLocal = 0;
        String totalAsString = "";

        for(int i = 0; i < priceListOfItems.size(); i++)
        {
            priceAsString = priceListOfItems.get(i);
            priceAsDouble = Double.parseDouble(priceAsString);
            totalPriceLocal += priceAsDouble;
        }
        totalAsString = String.valueOf(totalPriceLocal);
        return totalAsString;
    }

}