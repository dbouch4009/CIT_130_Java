public class MysterException extends Exception
{
    //Last case scenario
    public MysterException()
    {
        super("Mysterious, unforseen error");
    }

    public MysterException(String msg)
    {
        super(msg);
    }
}
