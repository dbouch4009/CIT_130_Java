public interface VehicleSpecs
{
    void setSpecsIndicator(String modelIn);
}
