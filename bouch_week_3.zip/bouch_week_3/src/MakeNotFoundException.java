public class MakeNotFoundException extends Exception
{
    //If care make ID is not defined
    public MakeNotFoundException()
    {
        super("Make not found");
    }

    public MakeNotFoundException(String msg)
    {
        super(msg);
    }

}
